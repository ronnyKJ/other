<?php

namespace Chub\XMindPHP;

/**
 * RuntimeException
 *
 * @author Vladimir Chub <v@chub.com.ua>
 */
class RuntimeException extends \RuntimeException
{

}
