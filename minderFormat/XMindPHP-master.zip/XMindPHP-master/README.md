XMindPHP
========

This is a XMind file format parsing library.
XMind is powerful mind mapping tool.

[![Build Status](https://secure.travis-ci.org/ChubV/XMindPHP.png)](http://travis-ci.org/ChubV/XMindPHP)

Installation
============

Just use your composer: `composer require chub/xmind-php`

Usage
=====

See tests/ directory for examples. Mind map used for tests can be found at `tests/res/cr.mind`

Todo
====

Add support for:

* boundaries
* summaries
* relationships
